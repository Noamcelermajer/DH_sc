#ifdef GL_ES
#extension GL_OES_standard_derivatives : enable
#endif
//#define AL //Alpha
//#define AT //Alpha Test
//#define LM //Light Map
//#define SP //Specular Map
//#define FG //Fog

#define LIGHTING
#define VC	//Vertex Color

#ifdef AL_LM
	#define AL
	#define LM
#endif

#ifdef AL_SP
	#define AL
	#define SP
#endif

#ifdef AL_FG
	#define AL
	#define FG
#endif

#ifdef AL_SP_LM
	#define AL
	#define SP
	#define LM
#endif

#ifdef AL_SP_FG
	#define AL
	#define SP
	#define FG
#endif

#ifdef AL_LM_FG
	#define AL
	#define LM
	#define FG
#endif

#ifdef AL_SP_LM_FG
	#define AL
	#define SP
	#define LM
	#define FG
#endif

#ifdef AT_LM
	#define AT
	#define LM
#endif

#ifdef AT_SP
	#define AT
	#define SP
#endif

#ifdef AT_FG
	#define AT
	#define FG
#endif

#ifdef AT_SP_LM
	#define AT
	#define SP
	#define LM
#endif

#ifdef AT_SP_FG
	#define AT
	#define SP
	#define FG
#endif

#ifdef AT_LM_FG
	#define AT
	#define LM
	#define FG
#endif

#ifdef AT_SP_LM_FG
	#define AT
	#define SP
	#define LM
	#define FG
#endif

#ifdef SP_LM
	#define SP
	#define LM
#endif

#ifdef LM_FG
	#define LM
	#define FG
#endif

#ifdef SP_LM_FG
	#define SP
	#define LM
	#define FG
#endif

#ifdef SP_FG
	#define SP
	#define FG
#endif

#if defined AL || defined AT
	#define ALPHA_MAP
#endif

varying mediump vec4 vTexCoord0;
// DH2 remaster (tools/trackb/remaster_shaders.py)
varying highp vec3 vNmWorldPos;
varying mediump vec3 vNmWorldNormal;
varying mediump vec3 vNmLightVec;
varying mediump vec3 vNmEyeVec;
varying lowp vec4 vNmVertexColor;
uniform lowp sampler2D NormalSampler;
uniform mediump float NormalStrength;
uniform mediump float NormalGreen;
uniform mediump float PixelLighting;
uniform mediump float SpecularBoost;
uniform mediump float FogCurve;
uniform mediump float AlphaCoverage;
uniform highp vec3 Light0Attenuation;
uniform highp vec4 Light0Ambientcolor;
uniform highp vec4 Light0Diffusecolor;
#ifdef FG
varying mediump float vNmFogDepth;
uniform mediump vec2 fogstartend;
#endif
#ifdef SP
uniform mediump float Glossiness;
#endif


#if defined VC || defined LIGHTING
	varying lowp vec4 vColor;
#endif

#ifdef SP
	//varying mediump vec2 vAttNdotHV;
	varying mediump float vAttNdotHV;
#endif

#ifdef FG
	varying lowp float vFogFactor;
#endif

uniform lowp sampler2D DiffuseSampler;

#ifdef ALPHA_MAP
	uniform lowp sampler2D AlphaSampler;
#endif

#ifdef AL
	//uniform lowp float Object_Alpha;
#endif

#ifdef SP
	uniform lowp sampler2D SpecularSampler;
	uniform lowp vec4 Light0Specularcolor;
	//uniform lowp float Spec_Saturation;
	//uniform lowp float Spec_Level;
	//uniform mediump float Glossiness;
#endif

#ifdef LM
	uniform lowp sampler2D LightMapSampler;
#endif

#ifdef FG
	uniform lowp vec4 fogcolor;   
#endif

 // main procedure, the original name was f
void main()
{
	lowp vec4 Diffuse = texture2D(DiffuseSampler, vTexCoord0.xy);

#ifdef ALPHA_MAP
	Diffuse.w = texture2D(AlphaSampler, vTexCoord0.xy).z;
#endif	
	
#ifdef AT
	if (AlphaCoverage > 0.0)
	{
		// DH2 remaster: alpha to coverage - the cut becomes a one-pixel ramp that MSAA turns into partial coverage
		Diffuse.w = clamp((Diffuse.w - 0.8) / max(fwidth(Diffuse.w), 1e-3) + 0.5, 0.0, 1.0);
		if (Diffuse.w <= 0.0) discard;
	}
	else if (Diffuse.w < 0.8) discard;
#endif

#if defined VC || defined LIGHTING
	lowp vec4 color = vColor;
	color *= Diffuse;
#else
	lowp vec4 color = Diffuse;
#endif

	// DH2 remaster: normal map and per-pixel lighting
	mediump vec3 dhN = normalize(vNmWorldNormal);
	mediump vec3 dhNp = dhN;
	if (NormalStrength > 0.0)
	{
		mediump vec3 nm = texture2D(NormalSampler, vTexCoord0.xy).xyz * 2.0 - 1.0;
		nm.y *= (NormalGreen < 0.0) ? -1.0 : 1.0;
		highp vec3 dp1 = dFdx(vNmWorldPos);
		highp vec3 dp2 = dFdy(vNmWorldPos);
		highp vec2 duv1 = dFdx(vTexCoord0.xy);
		highp vec2 duv2 = dFdy(vTexCoord0.xy);
		highp vec3 dp2perp = cross(dp2, dhN);
		highp vec3 dp1perp = cross(dhN, dp1);
		highp vec3 T = dp2perp * duv1.x + dp1perp * duv2.x;
		highp vec3 B = dp2perp * duv1.y + dp1perp * duv2.y;
		highp float invmax = inversesqrt(max(max(dot(T, T), dot(B, B)), 1e-12));
		dhNp = normalize(T * (invmax * nm.x) + B * (invmax * nm.y) + dhN * nm.z);
	}
	highp float dhDist = length(vNmLightVec);
	mediump vec3 dhL = vNmLightVec / max(dhDist, 1e-4);
	mediump float dhAtt = 1.0 / (Light0Attenuation.x + Light0Attenuation.y * dhDist + Light0Attenuation.z * dhDist * dhDist);
	// the original's vertex shader uses the world normal without normalising it (scaled meshes light brighter): kept
	mediump vec3 dhNs = dhNp * length(vNmWorldNormal);
	if (PixelLighting > 0.0)
	{
		mediump vec3 dhLight = Light0Ambientcolor.xyz + Light0Diffusecolor.xyz * (max(dot(dhNs, dhL), 0.0) * dhAtt);
		color = vec4(dhLight * vNmVertexColor.xyz, 1.0) * Diffuse;  // not clamped: the original light near the player exceeds 2
	}
	if (NormalStrength > 0.0)
	{
		// detail relief against Light0 tipped towards an oblique direction (world is Z-up)
		mediump vec3 dhRL = normalize(dhL + vec3(-0.55, 0.55, 0.35));
		mediump float relief = 1.0 + NormalStrength * (dot(dhNp, dhRL) - dot(dhN, dhRL));
		color.xyz *= clamp(relief, 0.5, 1.5);
	}


#ifdef LM
	color *= texture2D(LightMapSampler, vTexCoord0.zw);
#endif	

#ifdef SP
	lowp float Specular = texture2D(SpecularSampler, vTexCoord0.xy).z;
	//lowp float OutGrey = dot(color.xyz, vec3(0.3, 0.59, 0.11));
	//lowp vec3 Blend = mix(vec3(OutGrey, OutGrey, OutGrey), color.xyz, Spec_Saturation);
	//lowp vec3 specularColor = Specular * Specular * Spec_Level * Blend * Light0Specularcolor.xyz;
	lowp vec3 specularColor = Specular * Light0Specularcolor.xyz;
	
	//mediump float pf = vAttNdotHV.x * pow(vAttNdotHV.y, max(Specular * Glossiness, 0.0001));
	//mediump float pf = vAttNdotHV.x * pow(vAttNdotHV.y, Specular);
	//specularColor *= pf;
	
	if (PixelLighting > 0.0)
	{
		mediump vec3 dhH = normalize(dhL + normalize(vNmEyeVec));
		specularColor *= (dot(dhNs, dhL) > 0.0 ? dhAtt * pow(max(dot(dhNs, dhH), 0.0), Glossiness) : 0.0) * SpecularBoost;
	}
	else
	{
		specularColor *= vAttNdotHV;
	}
	color += vec4(specularColor, 0.0);
#endif

#ifdef FG
	mediump float dhFog = vFogFactor;
	if (FogCurve > 0.0)
	{
		mediump float f = clamp((vNmFogDepth - fogstartend.x) / max(fogstartend.y - fogstartend.x, 1e-3), 0.0, 1.0);
		dhFog = mix(f, f * f * (3.0 - 2.0 * f), FogCurve);
	}
	color.xyz = mix(color.xyz, fogcolor.xyz, dhFog);
	#ifdef ADDITIVEBLEND
		color.xyz *= fogFactor;
	#endif
#endif

#ifdef AL
	//color.w *= Object_Alpha;
#endif
	gl_FragColor = clamp(color, 0.0, 1.0);
	//gl_FragColor = color;
    return;
} // main end
